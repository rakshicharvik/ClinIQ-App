import React, { useEffect, useState } from "react";
import axios from "axios";

const API = "http://127.0.0.1:8000";

export default function App() {
  const [doctor, setDoctor] = useState({});
  const [slots, setSlots] = useState([]);
  const [apps, setApps] = useState([]);
  const [patient, setPatient] = useState("");
  const [contact, setContact] = useState("");
  const [slot, setSlot] = useState("");
  const [start, setStart] = useState("");
  const [end, setEnd] = useState("");

  useEffect(() => {
    fetchDoctor();
    fetchSlots();
    fetchApps();
  }, []);

  const fetchDoctor = async () => {
    const res = await axios.get(`${API}/doctor`);
    setDoctor(res.data);
  };

  const fetchSlots = async () => {
    const res = await axios.get(`${API}/availability`);
    setSlots(res.data);
  };

  const fetchApps = async () => {
    const res = await axios.get(`${API}/appointments`);
    setApps(res.data);
  };

  const addAvailability = async () => {
    await axios.post(`${API}/availability`, {
      doctor_id: doctor.id,
      start,
      end,
    });
    fetchSlots();
    setStart("");
    setEnd("");
  };

  const bookApp = async () => {
    await axios.post(`${API}/appointments`, {
      doctor_id: doctor.id,
      patient_name: patient,
      patient_contact: contact,
      start: slot.start,
      end: slot.end,
      status: "Booked",
    });
    fetchApps();
  };

  const updateStatus = async (id, status) => {
    await axios.put(`${API}/appointments/${id}/${status}`);
    fetchApps();
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-white text-gray-800 p-8">
      <div className="max-w-3xl mx-auto bg-white rounded-2xl shadow-md p-8 border border-gray-100">
        <h1 className="text-3xl font-bold text-blue-700 mb-2 flex items-center">
          🏥 ClinIQ — Clinic
        </h1>
        <p className="text-sm text-gray-500 mb-6">
          Single-doctor public booking page
        </p>

        <div className="mb-8">
          <h2 className="text-xl font-bold">Dr. {doctor.name}</h2>
          <p className="text-gray-600">
            {doctor.specialization} • {doctor.contact}
          </p>

          <div className="flex gap-2 mt-3">
            <input
              type="datetime-local"
              value={start}
              onChange={(e) => setStart(e.target.value)}
              className="border rounded-lg px-3 py-1 text-sm"
            />
            <input
              type="datetime-local"
              value={end}
              onChange={(e) => setEnd(e.target.value)}
              className="border rounded-lg px-3 py-1 text-sm"
            />
            <button
              onClick={addAvailability}
              className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-1 rounded-lg text-sm"
            >
              Add availability
            </button>
          </div>
        </div>

        <hr className="my-6" />

        <div className="mb-8">
          <h3 className="text-lg font-semibold mb-3">
            Book an Appointment (Public)
          </h3>
          <div className="flex flex-col gap-2">
            <input
              placeholder="Patient name"
              className="border rounded-lg px-3 py-2"
              value={patient}
              onChange={(e) => setPatient(e.target.value)}
            />
            <input
              placeholder="Contact number"
              className="border rounded-lg px-3 py-2"
              value={contact}
              onChange={(e) => setContact(e.target.value)}
            />
            <select
              className="border rounded-lg px-3 py-2"
              onChange={(e) =>
                setSlot(slots.find((s) => s.id === parseInt(e.target.value)))
              }
            >
              <option>Select slot</option>
              {slots.map((s) => (
                <option key={s.id} value={s.id}>
                  {new Date(s.start).toLocaleString()} -{" "}
                  {new Date(s.end).toLocaleString()}
                </option>
              ))}
            </select>
            <button
              onClick={bookApp}
              className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg"
            >
              Book Appointment
            </button>
          </div>
        </div>

        <hr className="my-6" />

        <div>
          <h3 className="text-lg font-semibold mb-3">
            Doctor — Appointments
          </h3>
          <div className="grid gap-4">
            {apps.map((a) => (
              <div
                key={a.id}
                className="border rounded-xl p-4 bg-gray-50 hover:bg-gray-100"
              >
                <p className="font-semibold text-gray-800">
                  {a.patient_name} ({a.patient_contact})
                </p>
                <p className="text-sm text-gray-600">
                  {new Date(a.start).toLocaleString()} →{" "}
                  {new Date(a.end).toLocaleString()}
                </p>
                <p className="mt-1 text-sm">
                  Status:{" "}
                  <span
                    className={`font-semibold ${
                      a.status === "Completed"
                        ? "text-green-600"
                        : a.status === "No-show"
                        ? "text-red-600"
                        : "text-blue-600"
                    }`}
                  >
                    {a.status}
                  </span>
                </p>
                <div className="mt-2 flex gap-2">
                  <button
                    onClick={() => updateStatus(a.id, "Completed")}
                    className="bg-green-500 hover:bg-green-600 text-white px-3 py-1 rounded-md text-sm"
                  >
                    Mark Completed
                  </button>
                  <button
                    onClick={() => updateStatus(a.id, "No-show")}
                    className="bg-red-500 hover:bg-red-600 text-white px-3 py-1 rounded-md text-sm"
                  >
                    Mark No-show
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
