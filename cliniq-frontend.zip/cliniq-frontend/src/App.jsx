import React, { useEffect, useState } from "react";
import axios from "axios";

const API = "http://127.0.0.1:8000";

export default function App() {
  const [doctor, setDoctor] = useState({});
  const [slots, setSlots] = useState([]);
  const [apps, setApps] = useState([]);
  const [patient, setPatient] = useState("");
  const [contact, setContact] = useState("");
  const [slot, setSlot] = useState("");
  const [start, setStart] = useState("");
  const [end, setEnd] = useState("");

  useEffect(() => {
    fetchDoctor();
    fetchSlots();
    fetchApps();
  }, []);

  const fetchDoctor = async () => {
    try {
      const res = await axios.get(`${API}/doctor`);
      setDoctor(res.data);
    } catch (e) {
      console.error("Error fetching doctor:", e);
    }
  };

  const fetchSlots = async () => {
    const res = await axios.get(`${API}/availability`);
    setSlots(res.data);
  };

  const fetchApps = async () => {
    const res = await axios.get(`${API}/appointments`);
    setApps(res.data);
  };

  const addAvailability = async () => {
    if (!start || !end) return alert("Please select start & end time.");
    await axios.post(`${API}/availability`, {
      doctor_id: doctor.id,
      start,
      end,
    });
    fetchSlots();
    setStart("");
    setEnd("");
  };

  const bookApp = async () => {
    if (!patient || !contact || !slot) {
      alert("Please fill all fields.");
      return;
    }
    await axios.post(`${API}/appointments`, {
      doctor_id: doctor.id,
      patient_name: patient,
      patient_contact: contact,
      start: slot.start,
      end: slot.end,
    });
    fetchApps();
    setPatient("");
    setContact("");
    setSlot("");
  };

  const updateStatus = async (id, status) => {
    await axios.put(`${API}/appointments/${id}?status=${status}`);
    fetchApps();
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-100 via-white to-blue-50 text-gray-800 py-10">
      <div className="max-w-4xl mx-auto bg-white rounded-2xl shadow-lg p-8 border border-gray-200">
        {/* Header */}
        <div className="flex items-center gap-4 mb-6">
          <img
            src="https://cdn-icons-png.flaticon.com/512/387/387561.png"
            alt="Doctor"
            className="w-16 h-16 rounded-full border-2 border-blue-300"
          />
          <div>
            <h1 className="text-3xl font-extrabold text-blue-700">
              ClinIQ — Clinic
            </h1>
            <p className="text-gray-500 text-sm">
              Single-doctor public booking portal
            </p>
          </div>
        </div>

        {/* Doctor Info */}
        <div className="bg-blue-50 rounded-xl p-5 shadow-inner mb-8">
          {doctor && doctor.name ? (
            <>
              <h2 className="text-xl font-semibold text-blue-800">
                Dr. {doctor.name}
              </h2>
              <p className="text-gray-600">
                {doctor.specialization} • {doctor.contact}
              </p>
            </>
          ) : (
            <p className="text-gray-500 italic">Fetching doctor details...</p>
          )}

          <div className="flex flex-wrap gap-3 mt-4">
            <input
              type="datetime-local"
              value={start}
              onChange={(e) => setStart(e.target.value)}
              className="border border-blue-200 rounded-lg px-3 py-1 text-sm focus:outline-none focus:ring-2 focus:ring-blue-300"
            />
            <input
              type="datetime-local"
              value={end}
              onChange={(e) => setEnd(e.target.value)}
              className="border border-blue-200 rounded-lg px-3 py-1 text-sm focus:outline-none focus:ring-2 focus:ring-blue-300"
            />
            <button
              onClick={addAvailability}
              className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-1.5 rounded-lg text-sm font-medium"
            >
              ➕ Add Availability
            </button>
          </div>
        </div>

        {/* Appointment Booking */}
        <div className="mb-10">
          <h3 className="text-lg font-semibold text-gray-800 mb-3">
            Book an Appointment (Public)
          </h3>
          <div className="bg-green-50 border border-green-100 rounded-xl p-5 shadow-inner flex flex-col gap-3">
            <input
              placeholder="Patient name"
              className="border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-green-300"
              value={patient}
              onChange={(e) => setPatient(e.target.value)}
            />
            <input
              placeholder="Contact number"
              className="border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-green-300"
              value={contact}
              onChange={(e) => setContact(e.target.value)}
            />
            <select
              className="border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-green-300"
              value={slot?.id || ""}
              onChange={(e) =>
                setSlot(slots.find((s) => s.id === parseInt(e.target.value)))
              }
            >
              <option value="">
                {slots.length === 0 ? "No slots available" : "Select slot"}
              </option>
              {slots.map((s) => (
                <option key={s.id} value={s.id}>
                  {new Date(s.start).toLocaleString()} →{" "}
                  {new Date(s.end).toLocaleString()}
                </option>
              ))}
            </select>
            <button
              onClick={bookApp}
              className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg font-medium"
            >
              Book Appointment
            </button>
          </div>
        </div>

        {/* Appointments */}
        <div>
          <h3 className="text-lg font-semibold text-gray-800 mb-3">
            Doctor — Appointments
          </h3>
          <div className="grid gap-4">
            {apps.length === 0 ? (
              <p className="text-gray-500 italic">No appointments yet.</p>
            ) : (
              apps.map((a) => (
                <div
                  key={a.id}
                  className="border border-gray-200 rounded-xl p-5 bg-gradient-to-r from-gray-50 to-white shadow-sm hover:shadow-md transition"
                >
                  <p className="font-semibold text-gray-800">
                    {a.patient_name} ({a.patient_contact})
                  </p>
                  <p className="text-sm text-gray-600">
                    {new Date(a.start).toLocaleString()} →{" "}
                    {new Date(a.end).toLocaleString()}
                  </p>
                  <p className="mt-1 text-sm">
                    Status:{" "}
                    <span
                      className={`font-semibold ${
                        a.status === "Completed"
                          ? "text-green-600"
                          : a.status === "No-show"
                          ? "text-red-600"
                          : "text-blue-600"
                      }`}
                    >
                      {a.status}
                    </span>
                  </p>
                  <div className="mt-3 flex gap-3">
                    <button
                      onClick={() => updateStatus(a.id, "Completed")}
                      className="bg-green-500 hover:bg-green-600 text-white px-3 py-1 rounded-md text-sm"
                    >
                      ✅ Mark Completed
                    </button>
                    <button
                      onClick={() => updateStatus(a.id, "No-show")}
                      className="bg-red-500 hover:bg-red-600 text-white px-3 py-1 rounded-md text-sm"
                    >
                      ❌ Mark No-show
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
