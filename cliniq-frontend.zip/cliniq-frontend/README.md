# 🩺 ClinIQ – Doctor Appointment Scheduling App

ClinIQ is a small full-stack SaaS application designed for individual doctors to manage their clinic appointments.

---

## 🚀 Features

- Doctor can set available timings  
- Public page for patients to book appointments  
- View, complete, or mark appointments as no-show  
- FastAPI backend with automated pytest HTML reports  

---

## 🧩 Tech Stack

### Backend
- **FastAPI**
- **SQLModel / SQLite**
- **Pytest + pytest-html**

### Frontend
- **React**
- **Axios**
- **Tailwind CSS**

---

Design Choices

# Kept the app simple and clear for a single-doctor clinic.

# Backend and frontend separated for modularity.

# Focused on testability and code cleanliness.

 Future Improvements

# Add login for doctors

# Appointment reminder notifications

# Deployment using Docker

👩‍💻 Author
Rakshitha K
FastAPI • React • SQL • Full Stack Developer


