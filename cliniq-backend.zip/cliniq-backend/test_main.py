from fastapi.testclient import TestClient
from sqlmodel import SQLModel, Session, select
from main import app, engine, Doctor
import datetime

client = TestClient(app)

# --- Ensure DB setup & data before tests ---
def setup_module(module):
    SQLModel.metadata.create_all(engine)
    with Session(engine) as session:
        doctor = session.exec(select(Doctor)).first()
        if not doctor:
            session.add(
                Doctor(
                    name="Rakshitha",
                    specialization="Dermatologist",
                    contact="9876543210",
                )
            )
            session.commit()

# --- Tests ---
def test_01_get_doctor():
    res = client.get("/doctor")
    assert res.status_code == 200
    data = res.json()
    assert data["name"].startswith("Dr.")

def test_02_add_availability_and_get():
    start = datetime.datetime.now().isoformat()
    end = (datetime.datetime.now() + datetime.timedelta(hours=1)).isoformat()
    res = client.post("/availability", json={"doctor_id": 1, "start": start, "end": end})
    assert res.status_code == 200

    res2 = client.get("/availability")
    assert res2.status_code == 200
    assert len(res2.json()) > 0

def test_03_book_appointment_and_get():
    start = (datetime.datetime.now() + datetime.timedelta(hours=2)).isoformat()
    end = (datetime.datetime.now() + datetime.timedelta(hours=3)).isoformat()

    res = client.post(
        "/appointments",
        json={
            "doctor_id": 1,
            "patient_name": "Moni",
            "patient_contact": "9999999999",
            "start": start,
            "end": end,
        },
    )
    assert res.status_code == 200
    assert res.json()["message"] == "Appointment booked successfully"

    res2 = client.get("/appointments")
    assert res2.status_code == 200
    assert any(a["patient_name"] == "Moni" for a in res2.json())

def test_04_invalid_double_booking():
    start = (datetime.datetime.now() + datetime.timedelta(hours=4)).isoformat()
    end = (datetime.datetime.now() + datetime.timedelta(hours=5)).isoformat()

    # first booking
    client.post(
        "/appointments",
        json={
            "doctor_id": 1,
            "patient_name": "Rive",
            "patient_contact": "8888888888",
            "start": start,
            "end": end,
        },
    )

    # duplicate booking
    res = client.post(
        "/appointments",
        json={
            "doctor_id": 1,
            "patient_name": "Rive",
            "patient_contact": "8888888888",
            "start": start,
            "end": end,
        },
    )
    assert res.status_code == 400

def test_05_update_status_and_invalid():
    res = client.put("/appointments/1?status=Completed")
    assert res.status_code == 200
    assert res.json()["message"] == "Status updated successfully"

    res2 = client.put("/appointments/999?status=Cancelled")
    assert res2.status_code == 404
