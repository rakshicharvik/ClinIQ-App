from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from sqlmodel import SQLModel, Field, Session, create_engine, select
from typing import Optional, List
from datetime import datetime

app = FastAPI(title="ClinIQ Doctor Appointment System")

# ------------------ DB Setup ------------------
sqlite_file_name = "test_cliniq.db"
engine = create_engine(f"sqlite:///{sqlite_file_name}", echo=False)

# ------------------ Models ------------------
class Doctor(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    name: str
    specialization: str
    contact: str


class Availability(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    doctor_id: int = Field(foreign_key="doctor.id")
    start: datetime
    end: datetime


class Appointment(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    doctor_id: int = Field(foreign_key="doctor.id")
    patient_name: str
    patient_contact: str
    start: datetime
    end: datetime
    status: str = "Booked"


# ------------------ Startup ------------------
@app.on_event("startup")
def on_startup():
    SQLModel.metadata.create_all(engine)
    with Session(engine) as session:
        # Add a default doctor if not present
        if not session.exec(select(Doctor)).first():
            session.add(
                Doctor(
                    name="Dr. Rakshitha",
                    specialization="Dermatologist",
                    contact="9876543210",
                )
            )
            session.commit()


# ------------------ CORS ------------------
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ------------------ Endpoints ------------------
@app.get("/doctor", response_model=Doctor)
def get_doctor():
    with Session(engine) as session:
        doctor = session.exec(select(Doctor)).first()
        if not doctor:
            raise HTTPException(status_code=404, detail="Doctor not found")
        return doctor


@app.post("/availability", response_model=Availability)
def add_availability(avail: dict):
    # ✅ Parse datetime strings properly
    avail["start"] = datetime.fromisoformat(avail["start"])
    avail["end"] = datetime.fromisoformat(avail["end"])
    new_avail = Availability(**avail)

    with Session(engine) as session:
        if not session.get(Doctor, new_avail.doctor_id):
            raise HTTPException(status_code=404, detail="Doctor not found")

        session.add(new_avail)
        session.commit()
        session.refresh(new_avail)
        return new_avail


@app.get("/availability", response_model=List[Availability])
def list_availability():
    with Session(engine) as session:
        return session.exec(select(Availability)).all()


@app.post("/appointments", response_model=dict)
def book_appointment(app_data: dict):
    # ✅ Parse datetime strings properly
    app_data["start"] = datetime.fromisoformat(app_data["start"])
    app_data["end"] = datetime.fromisoformat(app_data["end"])
    new_app = Appointment(**app_data)

    with Session(engine) as session:
        if not session.get(Doctor, new_app.doctor_id):
            raise HTTPException(status_code=404, detail="Doctor not found")

        # check for overlap
        overlap = session.exec(
            select(Appointment).where(
                (Appointment.doctor_id == new_app.doctor_id)
                & (Appointment.start == new_app.start)
                & (Appointment.status == "Booked")
            )
        ).first()

        if overlap:
            raise HTTPException(status_code=400, detail="Slot already booked")

        session.add(new_app)
        session.commit()
        session.refresh(new_app)
        return {"message": "Appointment booked successfully"}


@app.get("/appointments", response_model=List[Appointment])
def view_appointments():
    with Session(engine) as session:
        return session.exec(select(Appointment)).all()


@app.put("/appointments/{appointment_id}", response_model=dict)
def update_appointment_status(appointment_id: int, status: str):
    with Session(engine) as session:
        appointment = session.get(Appointment, appointment_id)
        if not appointment:
            raise HTTPException(status_code=404, detail="Appointment not found")

        appointment.status = status
        session.add(appointment)
        session.commit()
        return {"message": "Status updated successfully"}
@app.get("/")
def root():
    return {"message": "ClinIQ backend running successfully."}

@app.get("/favicon.ico")
def favicon():
    return {"message": "No favicon set."}
